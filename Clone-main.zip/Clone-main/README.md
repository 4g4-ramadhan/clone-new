
# Script run on termux or linux
```
➤ apt update && apt upgrade 
➤ apt install python2 -y
➤ apt install git -y
➤ rm -rf Clone
➤ git clone https://github.com/Tech-abm/Clone
➤ cd Clone 
➤ pip2 install requests && pip2 install mechanize 
➤ python2 cloning.indirect
```
# Python best true and false code in these my script 
```
➤ If os not file.path (#####) ✦ (01)
➤ If os not file.path (#####) ✦ (02)
➤ ruby nodejs termux setup storage etc
```
# Country 
```
➤ Tech Abm (Pakistan) 
```
# If you have any question or any problem, Guy's You Can contact me on my fb page 
<p align="center">
<a href="https://fb.com/Techabm"><img title="Facebook" src="https://img.shields.io/badge/Facebook-red?style=for-the-badge&logo=facebook"></a>
<a href="https://www.instagram.com/Techabm"><img title="Instagram" src="https://img.shields.io/badge/INSTAGRAM-purple?style=for-the-badge&logo=instagram"></a>
<a href="https://github.com/Tech-abm"><img title="Github" src="https://img.shields.io/badge/Github-TECH--ABM-blue?style=for-the-badge&logo=github"></a>
